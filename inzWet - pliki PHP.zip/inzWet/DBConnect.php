<?php

class DBConnect
{
    private $con;

    function __construct()
    {
    }

    function connect()
    {
        include_once dirname(__FILE__) . '/Constants.php';
        $this->con = new mysqli(HOST, USER, PASSWORD, DBNAME);
        if (mysqli_connect_errno()) {
            echo "Nie mozna polaczyc sie z baza..." . mysqli_connect_err();
        }
        return $this->con;
    }
}