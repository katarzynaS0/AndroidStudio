package com.example.inzWet;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;


public class AnimalAdapter extends RecyclerView.Adapter<AnimalAdapter.AnimalViewHolder> {


    private Context mCtx;
    private List<Animal> animalList;

    public AnimalAdapter(List<Animal> animalList, RecyclerView mRecyclerView) {
        this.animalList = animalList;
    }

    @Override
    public AnimalViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.animal_layout, null);
        return new AnimalViewHolder(view);
    }

    @Override
    public void onBindViewHolder(AnimalViewHolder holder, int position) {
        Animal animal = animalList.get(position);

        //loading the image
        //Glide.with(mCtx).load(animal.getName()).into(holder.imageView);

        holder.textViewAnimalName.setText(animal.getName());
        //holder.textViewIdOwner.setText(animal.getidOwner());
        holder.textViewDate.setText(animal.getDate());
        holder.textViewNamevet.setText(animal.getNamevet());
        holder.textViewSurname.setText(animal.getSurnamevet());
        holder.textViewOrders.setText(animal.getOrders());
        holder.textViewDesc.setText(animal.getDescription());
        holder.textViewPresc.setText(animal.getPrescriptioncode());
    }

    @Override
    public int getItemCount() {
        return animalList.size();
    }

    class AnimalViewHolder extends RecyclerView.ViewHolder {

        TextView textViewAnimalName, textViewIdOwner, textViewDate, textViewNamevet, textViewSurname, textViewOrders,textViewDesc, textViewPresc;
        Button button;
        //ImageView imageView;

        public AnimalViewHolder(View itemView) {
            super(itemView);

            textViewAnimalName = itemView.findViewById(R.id.animalname);
            //textViewIdOwner = itemView.findViewById(R.id.idowner);
            textViewDate = itemView.findViewById(R.id.date);
            textViewNamevet = itemView.findViewById(R.id.namevet);
            textViewSurname = itemView.findViewById(R.id.surnamevet);
            textViewOrders = itemView.findViewById(R.id.orders);
            textViewDesc = itemView.findViewById(R.id.description);
            textViewPresc = itemView.findViewById(R.id.prescriptioncode);


        }
    }
}