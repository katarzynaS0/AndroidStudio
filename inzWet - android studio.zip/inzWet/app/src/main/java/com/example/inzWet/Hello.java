package com.example.inzWet;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

public class Hello extends AppCompatActivity {

    private TextView textViewUsername;
    //PASEK MENU
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return true;
    }
    //OBSLUGA MENU
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.mojezwierzeta: startActivity(new Intent(getApplicationContext(),MyPets.class)); return true;
            case R.id.logout: startActivity(new Intent(getApplicationContext(),LoginActivity.class));; return true;
            default: return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Button mojezwierzeta;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hello_activity);

        mojezwierzeta = findViewById(R.id.mojezwierzeta);

        mojezwierzeta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                listazwierzat(view);
            }
        });
        if (!SharedPref.getInstance(this).isLoggedIn()){
            finish();
            startActivity(new Intent(this, LoginActivity.class));
        }

        textViewUsername = (TextView) findViewById(R.id.textViewUsername);
        textViewUsername.setText(SharedPref.getInstance(this).getUserName());
    }

    public void listazwierzat(View view){
        Intent i = new Intent(this, MyPets.class);
        startActivity(i);
        //finish();
    }

}

