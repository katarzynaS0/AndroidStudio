package com.example.inzWet;

import android.content.Context;
import android.content.SharedPreferences;


public class SharedPref {
    private static SharedPref mInstance;
    private static Context mCtx;

    private static final String SHAREDPREFNAME = "sharedpref";
    private static final String USERNAME = "username";
    private static final String EMAIL = "useremail" ;
    private static final String USERID = "userid";

    private SharedPref (Context context){
        mCtx = context;
    }
    public static synchronized SharedPref getInstance(Context context){
        if (mInstance == null ) {
            mInstance = new SharedPref(context);
        }
        return mInstance;
    }

    public boolean userLogin(int id, String username, String email){
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHAREDPREFNAME,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putInt(USERID, id);
        editor.putString(EMAIL, email);
        editor.putString(USERNAME, username);

        editor.apply();
        return true;
    }

    public boolean isLoggedIn(){
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHAREDPREFNAME,Context.MODE_PRIVATE);
        if(sharedPreferences.getString(USERNAME, null) != null){
            return true;
        }
        return false;
    }

    public boolean logout(){
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHAREDPREFNAME,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
        return true;
    }

    public String getUserName(){
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHAREDPREFNAME,Context.MODE_PRIVATE);
        return sharedPreferences.getString(USERNAME, null);
    }

    public String getUserID(){
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHAREDPREFNAME,Context.MODE_PRIVATE);
        return sharedPreferences.getString(USERID, null);
    }
}

