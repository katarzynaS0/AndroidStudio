package com.example.inzWet;

public class Animal {
    private String name, date, namevet, surnamevet, orders, description, prescriptioncode;
    //private Integer idOwner;


    public Animal (String name, String date, String namevet, String surnamevet,
                   String orders, String description, String prescriptioncode ){

        this.name = name;
        //this.idOwner = idOwner;
        this.date = date;
        this.namevet = namevet;
        this.surnamevet = surnamevet;
        this.orders = orders;
        this.description = description;
        this.prescriptioncode = prescriptioncode;

    }

    public Animal() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setNamevet(String namevet) {
        this.namevet = namevet;
    }

    public void setSurnamevet(String surnamevet) {
        this.surnamevet = surnamevet;
    }

    public void setOrders(String orders) {
        this.orders = orders;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setPrescriptioncode(String prescriptioncode) {
        this.prescriptioncode = prescriptioncode;
    }
/*
    public void setIdOwner(Integer idOwner) {
        this.idOwner = idOwner;
    }

    public int getidOwner() {
        return idOwner;
    }
    */

    public String getDate() {
        return date;
    }
    public String getNamevet() {
        return namevet;
    }
    public String getSurnamevet() {
        return surnamevet;
    }
    public String getOrders() {
        return orders;
    }
    public String getDescription() {
        return description;
    }
    public String getPrescriptioncode() {
        return prescriptioncode;
    }
}
