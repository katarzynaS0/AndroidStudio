package com.example.inzWet;

public class Constants {
    //private static final String url = "http://192.168.0.101/Weterynarz/";
    private static final String HOST = "http://192.168.0.200/inzWet/";

    public static final String ENDPOINT_USER_LOGIN = HOST + "userLogin.php";
    public static final String ENDPOINT_API = HOST + "Api.php";
}
