<?php
require_once 'DBOperations.php';

$response = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['email']) && isset($_POST['password'])) {
        $db = new DBOperations();

        if ($db->userLogin($_POST['email'], $_POST['password'])) {
            $user = $db->getUserByEmail($_POST['email']);
            $response['error'] = false;
            $response['id'] = $user['id'];
            $response['email'] = $user['email'];
            $response['name'] = $user['name'];
            $response['message'] = "Login successfull";
		} else {
            $response['error'] = true;
            $response['message'] = "Niepoprawne dane";
        }
    } else {
        $response['error'] = true;
        $response['message'] = "Wypelnij wszystkie pola";
    }
}
echo json_encode($response);

