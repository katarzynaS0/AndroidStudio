<?php

include('db_connect.php');

$stmt = $conn->prepare("SELECT id_owner, name, species FROM animal");

$stmt ->execute();
$stmt -> bind_result($id_owner, $name, $species);

$animal = array();

while($stmt ->fetch()){

    $temp = array();
	
	$temp['id_owner'] = $id_owner;
	$temp['name'] = $name;
	$temp['species'] = $species;

	array_push($animal,$temp);
	}

	echo json_encode($animal);

?>