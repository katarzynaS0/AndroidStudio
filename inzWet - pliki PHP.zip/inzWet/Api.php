<?php 
include('db_connect.php');
 
 if (mysqli_connect_errno()) {
 echo "Failed to connect to MySQL: " . mysqli_connect_error();
 die();
 }
 
 //creating a query
 $stmt = $conn->prepare("SELECT visit.date, animal.name, vet.name, vet.surname, history.orders, history.description, prescription.access_code FROM visit JOIN history ON visit.id_visit = history.id_visit JOIN animal ON visit.id_animal = animal.id_animal JOIN vet ON visit.id_vet = vet.id_vet JOIN prescription ON history.id_prescription = prescription.id_prescription WHERE animal.id_animal = 1;");
 
 //executing the query 
 $stmt->execute();
 
 //binding results to the query 
 $stmt->bind_result($date, $animalname, $vetname, $vetsurname, $orders, $description, $access_code);
 
 $visit = array(); 
 
 //traversing through all the result 
 while($stmt->fetch()){
 $temp = array();
 $temp['date'] = $date; 
 $temp['animalname'] = $animalname; 
 $temp['vetname'] = $vetname; 
 $temp['vetsurname'] = $vetsurname; 
 $temp['orders'] = $orders; 
 $temp['description'] = $description; 
 $temp['access_code'] = $access_code; 
 array_push($visit, $temp);
 }
 
 //displaying the result in json format 
 echo json_encode($visit);