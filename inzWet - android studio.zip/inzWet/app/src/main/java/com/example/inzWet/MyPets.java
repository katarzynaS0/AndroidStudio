package com.example.inzWet;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MyPets extends AppCompatActivity {

    private RequestQueue mRequestQueue;
    private StringRequest mStringRequest;
    private List <Animal> AnimalList = new ArrayList<>();
    private RecyclerView mRecyclerView;
    private AnimalAdapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    private TextView textViewInfo;
    //PASEK MENU
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return true;
    }
    //OBSLUGA MENU
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.mojezwierzeta: startActivity(new Intent(getApplicationContext(),MyPets.class)); return true;
            case R.id.logout: startActivity(new Intent(getApplicationContext(),LoginActivity.class));; return true;
            default: return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        displayInfo();


    }

    public void listazwierzat(View view){
        Intent i = new Intent(this, MyPets.class);
        startActivity(i);
        //finish();
    }

    private void displayInfo() {
        mRequestQueue = Volley.newRequestQueue(this);
        //List<Animal> AnimalList = new ArrayList<>();
        StringRequest stringRequest = new StringRequest(Request.Method.GET,Constants.ENDPOINT_API, odpowiedz-> {
            try {
                JSONArray obj = new JSONArray(odpowiedz);
                       for (int i=obj.length()-1; i>=0; i--) {
                           JSONObject animal = obj.getJSONObject(i);

                           AnimalList.add(
                                   new Animal(
                                           animal.getString("animalname"),
                                           animal.getString("date"),
                                           animal.getString("vetname"),
                                           animal.getString("vetsurname"),
                                           animal.getString("orders"),
                                           animal.getString("description"),
                                           animal.getString("access_code")));
                       }
                       mRecyclerView.setHasFixedSize(true);
                       mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
                       mRecyclerView.setItemAnimator(new DefaultItemAnimator());
                       mRecyclerView.setAdapter(new AnimalAdapter(AnimalList, mRecyclerView));
                    } catch (JSONException e) {
                e.printStackTrace();
            }
            }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(MyPets.this,"Blad",Toast.LENGTH_SHORT.show());
            }

        });
       mRequestQueue.add(stringRequest);
    }


}

