<?php
const DBNAME = 'wet';
const USER = 'root';
const PASSWORD = '';
const HOST = 'localhost';