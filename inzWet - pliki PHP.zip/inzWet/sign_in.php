<?php

	include('db_connect.php');

	if($_SERVER['REQUEST_METHOD'] == 'POST')
	{
		$email=$_POST['email'];
		$password=$_POST['password'];
		$que=mysqli_query($conn,"select * from users where (email ='$email' && password='$password' && Id_type='3')");
		$row=mysqli_num_rows($que);

		if($row > 0)
		{
		//sprawdzenie hasla
		if (password_verify($_POST['password'], $password))
	          	{
			$result["success"] = "1";
		        $result["message"] = "Login successful";
		       // Encoding result into Json
		       echo json_encode($result);
			}
		else {
		//incorrect password
		$result["success"] = "0";
		$result["message"] = "Incorrect email or password";
		//Encoding the result to json
		 echo json_encode($result);}
	        	
	        }

		else
			{

		$result["success"] = "0";
		$result["message"] = "Incorrect email or password";

		//Encoding the result to json
		 echo json_encode($result);
				
			}
	}

?>
