<?php
require_once dirname(__FILE__) . '/DBConnect.php';

class DBOperations
{
    private $con;

    function __construct()
    {
        $db = new DBConnect();
        $this->con = $db->connect();
    }

    public function userLogin($email, $pass)
    {
        $password = md5($pass);
        $stmt = $this->con->prepare("SELECT id FROM users WHERE email = ? AND password = ?");
        $stmt->bind_param("ss", $email, $password);
        $stmt->execute();
        $stmt->store_result();
        return $stmt->num_rows > 0;
    }

    public function getUserByEmail($email)
    {
        $stmt = $this->con->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public function getAnimals()
    {
        $stmt = $this->con->prepare("SELECT visit.date, animal.name, vet.name, vet.surname, history.orders, history.description, prescription.access_code FROM visit JOIN history ON visit.id_visit = history.id_visit JOIN animal ON visit.id_animal = animal.id_animal JOIN vet ON visit.id_vet = vet.id_vet JOIN prescription ON history.id_prescription = prescription.id_prescription WHERE animal.id_animal = 1;");
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

}
